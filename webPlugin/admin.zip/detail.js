importJs('lib/text')

function main(){
    var detail ={
            status: 0,
            msg: "",
            children: {}
        }

    text.split('\n')
    .map(s=>s.trim())
    .filter(s=>s.startsWith('set'))
    .forEach(ss=>{
        msg=ss.split('#')[1]
        arr=ss.split('#')[0].trim().split(/\s+/)
        let obj=detail
        for (let i = 1; i < arr.length; i++) {
            obj.children=obj.children||{}
            s=arr[i]
            if(i==2||i==arr.length-1){
                obj.children[s]={
                    value:arr.slice(i+1).join(" "),
                    text:msg
                }
                if(!obj.children[s].value||obj.children[s].value=='?'||/x+/.test(obj.children[s].value)){
                    delete obj.children[s].value
                }
                return
            }
            if(!obj.children[s]){
                obj.children[s]={
                        children:{}
                }
            }
            obj=obj.children[s]
        }
    })
    
    detail.data={
        options:detail.children
    }
    delete detail.children
    
    __response.json(detail)
}
main()





    