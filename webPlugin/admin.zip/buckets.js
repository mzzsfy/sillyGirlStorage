function main(){
    let res = __response
	let data = {
	   status: 0,
	   msg: "ok",
	   data: bucket.buckets()
	}

	res.json(data)
}
main()