(function(){
    let password = sillyGirl.bucketGet("sillyGirl","adminPassword")
    importJs('lib/base64')
    if (!password||password.length<=0){
        password=Base64.btoa(Math.random()+"").replace(/[^A-Za-z0-9]/g,'').substr(1,11)
        console.error("控制台未设置密码,账号:admin,已生成随机管理密码: "+password)
        sillyGirl.bucketSet("sillyGirl","adminPassword",password)
    }
    let h=__request.header("authorization")
    let p="Basic "+Base64.btoa((sillyGirl.bucketGet("sillyGirl","adminUsername")||"admin")+":"+password)
    if(p!=h){
        __response.status(401).header("www-authenticate",'Basic realm="sillyGirl"')
    }
})()