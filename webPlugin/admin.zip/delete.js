function main(){
    
    var req = __request
    var res = __response

    var datas = req.json().data

    for (let data of datas) {
        sillyGirl.bucketSet(data.bucket, data.key, null)
    }

    res.json({
       status: 0,
       msg: "删除操作完成",
       data:datas
    })

}
main()