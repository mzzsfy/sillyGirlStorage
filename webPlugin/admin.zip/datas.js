function main(){
    let req = __request
    let res = __response
    if(req.method()=='DELETE'){
    	let bucketQ = req.query("bucket")
    	let key = req.query("key")
    	sillyGirl.bucketSet(bucketQ, key, null)
    
    	res.json({
    	   status: 0,
    	   msg: "删除操作完成"
    	})
    }else if (req.method()=='GET'){
    	let bucketQ = req.query("bucket")
    	let idQ = req.query("key")
    	let valueQ = req.query("value")
    	let rows = [];
        let buckets=[]
        if(bucketQ){
    	   buckets= [bucketQ]
    	}else{
    	    importJs('lib/text')
    	    buckets=text.split('===',1)[0].trim().split('set').filter(s=>s).map(s=>s.trim().split('#',1)[0].trim())
    	}
    	for (let bucket of buckets) {
    	   let keys = sillyGirl.bucketKeys(bucket)
    	   for (let key of keys) {
    			rows.push({
    				 id: `${bucket}@${key}`,
    				 bucket: bucket,
    				 key: key,
    				 value: sillyGirl.bucketGet(bucket, key)
    			});
    	   }
    	}
    
    	let ret = []
    
    	for (let row of rows) {
    	   if (idQ && row.id.indexOf(idQ) == -1) {
    			continue;
    	   }
    	   if (valueQ && row.value.indexOf(valueQ) == -1) {
    			continue;
    	   }
    	   if(ret.length>=3000){ 
    	       break;
    	   }
    	   ret.push(row);
    	}
    
    	let data = {
    	   status: 0,
    	   msg: ret.length>=3000?"数据量过大,只加载部分数据":"ok",
    	   data: {
    			count: bucketQ?bucket.size(bucketQ):ret.length,
    			rows: ret
    	   }
    	}
    
    	res.json(data)
    }else{
    	let data = req.json()
    	let bucket = data.bucket
    	let key = data.key
    	let value = data.value
    
    	sillyGirl.bucketSet(bucket, key, value)
    	res.json({
    	   status: 0,
    	   msg: "新增/修改成功"
    	})
    }
}
main()