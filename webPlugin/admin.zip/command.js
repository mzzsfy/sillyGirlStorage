importJs('lib/text')

function main(){
    text=text.split("====")
    text=text[text.length-1].trim().replace(/\n{2,}/g,'\n\n')
    var detail ={
            status: 0,
            msg: "",
            data:{
                text:text
            }
        }
    __response.json(detail)
}
main()





    